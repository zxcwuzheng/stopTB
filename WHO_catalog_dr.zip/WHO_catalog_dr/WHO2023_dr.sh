
python3 snp2drug.py WHO2023_resistance_sorted.list test.snp
Rscript adjust.R test.txt test.dr
rm test.txt
