import os
import pandas as pd
import sys
import re


# return dict
# key is drug name
# value is the resistance information
def drugMutation(infile):

    result = {}
    with open(infile, 'r') as f:
        f.readline()

        for line in f:
            line = line.rstrip()
            lines = line.split('\t')
            lines[0] = lines[0].upper()
            if not lines[0] in result:
                result[lines[0]] = [lines]
            else:
                result[lines[0]].append(lines)
    return result



def snp2drug(drug_dict, *snp_file):

    for file in snp_file:

        result = {}
        outfile = os.path.splitext(os.path.basename(file))[0] + '.txt'
        snp = pd.read_table(file, header=None)
        snp.columns = ['position', 'ref_nt', 'alt_nt', 'freq', 'DP', 'RD','AD']

        # DP > 5:
        snp = snp[snp.DP >= 5]
        # forward and reverse alt reads > 1
        AD_reads = snp.AD.str.split('=',expand=True)[1]
        FAD = AD_reads.str.split(':',expand=True)[0].astype('int')
        RAD = AD_reads.str.split(':',expand=True)[1].astype('int')
        snp = snp[(FAD >= 1) & (RAD >= 1)]

        snp['variant'] = snp.position.astype('str') + '_' + snp.ref_nt + '_' + snp.alt_nt
        snps = snp['variant'].tolist() # position_ref_alt

        # for each drug
        for drug in drug_dict:
            info = drug_dict[drug]
            for line in info:
                var = line[8]
                if ',' in var: # multiple mutations
                    var = var.split(',')
                    loc = [i for i in var if i in snps]
                    if len(loc)==len(var):
                        if drug in result: # whether the mutations name is same
                            if not line[8] in result[drug][2]: # raw: if not line[1] in result[drug][1]
                                if not line[1] in result[drug][1]: # if same mutation name
                                    result[drug][1] = '/'.join([result[drug][1],line[1]]) # raw: result[drug][1] = '/'.join(set([result[drug][1],line[1]]))
                                    result[drug][2] = '/'.join([result[drug][2],line[8]])
                        else:
                            result[drug] = [drug, line[1], line[8],'R']
                else:
                    if var in snps:
                        if drug in result:
                            if not line[8] in result[drug][2]: # raw: if not line[1] in result[drug][1]
                                if not line[1] in result[drug][1]: # if same mutation name
                                    result[drug][1] = '/'.join([result[drug][1],line[1]]) # raw: result[drug][1] = '/'.join(set([result[drug][1],line[1]]))
                                    result[drug][2] = '/'.join([result[drug][2],line[8]])
                        else:
                            result[drug] = [drug, line[1], line[8],'R']
                
            if not drug in result:
                result[drug] = [drug, 'none', 'none',"S"]

        with open(outfile, 'w') as w:
            w.write('drugs\tresistance mutations\tvariants\tbinary resistance\n')
            for i in result:
                w.write('\t'.join(result[i]) + '\n')

                
drug_dict = drugMutation(sys.argv[1])
snp2drug(drug_dict, *sys.argv[2:])