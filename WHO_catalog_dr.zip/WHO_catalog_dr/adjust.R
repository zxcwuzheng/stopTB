library(stringr)

args <- commandArgs(trailingOnly = TRUE)

a = read.delim(args[1],check.names = F)

mutation <- a$`resistance mutations`
var_pos <- a$variants


new_mutation <- c()
new_pos <- c()


for(i in 1:length(mutation)){
  
  mut <- mutation[i]
  pos <- var_pos[i]
  
  if(str_count(mut, '_p.') >=2){
    
    split_mut <- str_split(mut, '/', simplify = T)[1,]
    split_pos <- str_split(pos, '/', simplify = T)[1,]
    
    remain_mut <- c()
    remain_pos <- c()
    
    if(any(!str_detect(split_mut, '_p'))){ 
      
      remain_mut <- c(remain_mut, 
                      split_mut[!str_detect(split_mut, '_p')])
      
      remain_pos <- c(remain_pos, 
                      split_pos[!str_detect(split_mut, '_p')])
      
    }
    
    if(any(str_detect(split_pos,','))){ 
      
      remain_pos <- c(remain_pos, 
                      split_pos[str_detect(split_pos, ',')])
      remain_mut <- c(remain_mut, 
                      split_mut[str_detect(split_pos, ',')])
      
    }
    
    setdiff_mut <- split_mut[!split_mut %in% remain_mut] 
    setdiff_pos <- split_pos[!split_pos %in% remain_pos]
    
    if(length(setdiff_mut)>0){ 
    
      if(length(setdiff_mut)==1){ 
        
        if(all(!str_detect(remain_pos,setdiff_pos))){ 
          remain_mut <- c(remain_mut,
                          setdiff_mut)
        
          remain_pos <- c(remain_pos,
                          setdiff_pos)
        }
        
      }else{
        ind <- c()
        
        for(j in 1:length(setdiff_mut)){ 
          
          if(any(str_detect(remain_pos,setdiff_pos[j]))){
            ind <- c(ind,TRUE)
            
          }else{
            
            j_mut <- setdiff_mut[j]
            other_mut <- setdiff(setdiff_mut,j_mut)
            
            j_gene <- str_split(j_mut, '_p.')[[1]][1]
            j_codon <- str_split(j_mut, '_p.')[[1]][2]
            j_codon <- str_sub(j_codon,1, str_length(j_codon)-3)
            
            ind2 <- c()
            for(k_mut in other_mut){
              
              k_gene <- str_split(k_mut, '_p.')[[1]][1]
              k_codon <- str_split(k_mut, '_p.')[[1]][2]
              k_codon <- str_sub(k_codon,1, str_length(k_codon)-3)
              
              if((j_gene==k_gene) & (j_codon==k_codon)){
                ind2 <- c(ind2,TRUE)
              }
              
            }
            
            if(length(ind2)>0){
              ind <- c(ind, TRUE)
            }else{
              ind <- c(ind,FALSE)
            }
          }
        }
        
        remain_mut <- c(remain_mut,
                        setdiff_mut[!ind])
        
        remain_pos <- c(remain_pos,
                        setdiff_pos[!ind])
        
      }
    }
    
    new_mutation <- c(new_mutation,
                      paste(remain_mut,collapse = '/'))
    new_pos <- c(new_pos,
                 paste(remain_pos, collapse = '/'))
    
  }else{
    
    new_mutation <- c(new_mutation, mut)
    new_pos <- c(new_pos, pos)
  }
  
}

a$`resistance mutations` <- new_mutation
a$`resistance mutations` <- ifelse(a$`resistance mutations`=='',
                                   'none',
                                   a$`resistance mutations`)
a$variants <- new_pos
a$variants <- ifelse(a$variants=='',
                     'none',
                     a$variants)
a$`binary resistance` <- ifelse(a$`resistance mutations`=='none',
                                'S',
                                'R')
write.table(a,file = args[2],
            sep = '\t',
            row.names = F,
            col.names = T,
            quote = F)

